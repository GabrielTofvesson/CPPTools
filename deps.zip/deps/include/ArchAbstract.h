#pragma once

// Add architecture abstraction things here. I.e. things that make the difference between architectures less visible

#ifndef ulong_64b
#define ulong_64b unsigned long long
#endif